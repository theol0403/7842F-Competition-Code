#pragma once
#include "main.h"

#include "lib7842/vision/objectTracking.hpp"

void ObjectTrackingTask(void*);

#pragma once
#include "main.h"

#include "7842FMain/Shared/MotorConfig.hpp"
#include "7842FMain/Shared/FlywheelTask.hpp"


void DriverMainTask(void*);

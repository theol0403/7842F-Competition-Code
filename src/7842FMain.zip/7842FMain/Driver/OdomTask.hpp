#pragma once
#include "main.h"

#include "7842FMain/Shared/MotorConfig.hpp"


void driverOdomTask(void*);
